Date: Mar 5, 2025

Initial Data: 01DataVersions/FULLpubchemChemblLOCKED2324
_____________________________________________________________

Docs in this folder ---- Backup copy name in Backups folder:

Cut1NoBROAD ----- CutNoActivityProof
Cut2FilteredDefinedActivity ----- CutFilteredDefinedActivity
Cut3FilterAndLit ----- Cut2aWithLit
______________________________________________________________

DATA HANDLING EXPLANATIONS
______________________________________________________________

First edit: Removed values with no proof of activity (via IC50, KD, etc).
	Docs: CutNoBROAD -> Cut1NoBROAD (2132), CutNoActivityProof (2132)

Second edit: Removed values with no declared activity (no 'Inactive' or 'Active' label)
	Docs: CutFilteredDefinedActivity (430), Cut2FilteredDefinedActivity (430)

Third edit: Added data from literature: 01DataVersions/LitInhibitors
	Doc: Cut2Filter -> Cut2aWithLit (444), Cut3FilterAndLit (444)

